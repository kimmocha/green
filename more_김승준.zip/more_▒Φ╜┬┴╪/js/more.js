$(function(){
    function listMore(){
       win=$(window).width();
        if(win <= 640){
            let  x=2;
            $("#shop_box li").slice(0, 2).show();           
            $('.more_btn').click(function(e){
                e.preventDefault();
                $("#shop_box li:hidden").slice(0, 2).show();   
            });
       }else if(win>640 && win<=768)
        {
            $("#shop_box li").slice(0, 3).show(); 
            $(".more_btn").click(function(e){ 
                e.preventDefault();
                $("#shop_box li:hidden").slice(0, 3).show();
             });    
         } else{
            $("#shop_box li").slice(0, 4).show(); 
            $(".more_btn").click(function(e){ 
                e.preventDefault();
                $("#shop_box li:hidden").slice(0, 4).show();
             });
        } 
    }
    listMore();
    $(window).on("resize",function(){
        listMore()       
        location.reload();
        });
      

});

$(function(){

$(".top_menu li a").mouseenter(function(){
    $(this).stop().css("color","tomato")
});
$(".top_menu li a").mouseleave(function(){
    $(this).stop().css("color","#666")
});

});
